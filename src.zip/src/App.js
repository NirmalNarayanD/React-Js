import React from "react";
import Get from "./Get";
import Addform from "./Addform"
import View from "./View"
import Update from "./Update"
import {BrowserRouter as Router,Switch,Route} from "react-router-dom";
function App() {
  return (
    <div>
      <Router>
        <Switch>
          <Route path="/" exact component={Get} />
          <Route path="/addform" component={Addform} />
          <Route path="/view/:id" component={View} />
          <Route path="/update/:id" component={Update} />
        </Switch>
      </Router>
      </div>
  );
}
export default App;
