import React, { useState } from "react";
function Demo1(){
    const [demo,setDemo]=useState({name:"jeevi"})
    const addChange =()=>{
          setDemo({
              name:"nathan"
          })
    }
    return(
        <div>
            {demo.name}
            <button onClick={addChange}>AddChange</button>
        </div>
    )
}
export default Demo1;