import React from "react";
import axios from "axios";
import {withRouter} from "react-router";

class View extends React.Component {
 constructor(props) {
    super(props);
    this.state={
        datas : []
    }
  }
  
  componentDidMount() {
 const {id}=this.props.match.params;
 this.getData (id)
  }


  getData =(id)=>{ 
     axios.get(`https://reqres.in/api/users/${id}`).then((resp) => {
    const datas = resp.data.data;
    this.setState({ datas });
    console.log(resp);
  });}
  render() {
const {datas}=this.state
    return (
      <>
      <table>
        <tbody>
        <tr>
          <td>{datas.id}</td>
          <td>{datas.fname}</td>
          <td>{datas.lname}</td>
          <td>{datas.email}</td>
          <td><img src={datas.avatar} alt="avatar" /></td>
        </tr></tbody>
      </table>
        {/* <div>
        {datas.id}
        {datas.fname}
        {datas.lname}
        {datas.email}
        <img src={datas.avatar} alt="avatar" />
        </div> */}
      </>
    );
  }
}
export default withRouter (View);