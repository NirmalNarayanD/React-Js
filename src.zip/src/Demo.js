import React from "react";

class Demo extends React.Component {
  constructor() {
    super();
    this.state = {
      name: "ippopay",
    };
  }
  handleChange = (e) => {
e.preventDefault()
this.setState({
    name:"RoamSoft"
})
  };
  render() {
    return (
      <div>
        {this.state.name}
        <button onClick={this.handleChange}>Change</button>
      </div>
    );
  }
}
export default Demo;
