import axios from "axios";
import React from "react";
import { Link } from "react-router-dom";
import View from "./View";
class Get extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tab: [],
    };
  }

  componentDidMount() {
    axios.get("https://reqres.in/api/users").then((resp) => {
      const tab = resp.data.data;
      this.setState({ tab });
      console.log(resp);
    });
  }

  deleteRow(id) {
    axios.delete(`https://reqres.in/api/users/${id}`).then((res) => {
      console.log(res);
      console.log(res.data);

      const tab = this.state.tab.filter((item) => item.id !== id);
      this.setState({ tab });
    });
  }

  render() {
    return (
      <>
        <Link to="addform">
          <button>AddForm</button>
        </Link>
        <br />
        <br />
        <table>
          <thead>
            <tr>
              <th>S.no</th>
              <th>Email</th>
              <th>FirstName</th>
              <th>LastName</th>
              <th>Avatar</th>
              <th>Page</th>
            </tr>
          </thead>
          <tbody>
            {this.state.tab.map((items) => (
              <tr key={items}>
                <td>{items.id}</td>
                <td>{items.email}</td>
                <td>{items.first_name}</td>
                <td>{items.last_name}</td>
                <td>
                  <img src={items.avatar} alt="avatar" />
                </td>
                <td>
                  <Link to={`/view/${items.id}`}>
                    <button onClick={View}>Vist</button>{" "}
                  </Link>
                </td>
                <td>
                <button>
                  <Link to={`/update/${items.id}`}>
                    button
                  </Link>
                  </button>
                </td>
                <td>
                  <button onClick={(e) => this.deleteRow(items.id, e)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </>
    );
  }
}
export default Get;
