import axios from "axios";
import React from "react";
import "react-toastify/dist/ReactToastify.css";
class Addform extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      fname: "",
      lname: "",
      items: [],
    };
  }

 

  componentDidMount() {
    const { id } = this.props.match.params;
    this.getData(id);
  }

  getData = (id) => {
    axios.get(`https://reqres.in/api/users/${id}`).then((resp) => {
      const items = resp.data.data;
      this.setState({ items });
      console.log(resp);
    });
  };


  onChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  
  handleSubmit = (e) => {
    

    
      axios
        .patch("https://reqres.in/api/users", this.state)
        .then((response) => {
          console.log(response.data.data);
        });
        e.preventDefault(); 
    }
  
  render() {
    const { items } = this.state;

    return (
      <form onSubmit={this.handleSubmit}>
        <label htmlFor="emails">Email</label>
        <input
          type="email"
          id="emails"
          name="emails"
          defaultValue={items.email}
          onChange={this.onChange}
        />
        <br />
        <br />
        <label htmlFor="fname">First Name</label>
        <input
          type="text"
          id="fname"
          name="fname"
          defaultValue={items.first_name}
          onChange={this.onChange}
        />
        <br />
        <br />
        <label htmlFor="lname">Last Name</label>
        <input
          type="text"
          id="lname"
          name="lname"
          defaultValue={items.last_name}
          onChange={this.onChange}
        />
        <br />
        <br />
        <button onClick={this.handleSubmit}>Submit</button>
      </form>
    );
  }
}


export default Addform;
