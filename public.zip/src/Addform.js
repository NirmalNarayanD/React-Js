import axios from "axios";
import React from "react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
class Addform extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      job: "",
    };
  }
  
  onChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = (e) => {
    e.preventDefault();
    const user = {
      name: this.state.name,
      job: this.state.job
     
    };
   
    if (this.state.name === "") {
      toast.info("please enter the name");
    } 
    else if
      (this.state.job === "") {
        toast.info("please enter the job");
    }
    else{
      toast.success("success")
      axios.post("https://reqres.in/api/users", user)
      .then((response) => {
        console.log(response.data);
      });
    }
   
  };
  render() {
    
    return (
      
      <form onSubmit={this.handleSubmit}>
             <lable htmlFor="name">Name</lable>
        <input
          type="text"
          id="name"
          name="name"
          value={this.state.name}
          onChange={this.onChange}
        />
        <br/>
        <br/>
        <lable htmlFor="job">Job</lable>
        <input
          type="text"
          id="job"
          name="job"
          value={this.state.job}
          onChange={this.onChange}
        />
        <br/>
        <br/>
        <button >Submit</button>
        <ToastContainer />
      </form>
    );
  }
}

export default Addform;
